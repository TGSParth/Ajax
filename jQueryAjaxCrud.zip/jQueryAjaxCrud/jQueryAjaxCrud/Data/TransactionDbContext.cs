﻿using jQueryAjaxCrud.Models;
using Microsoft.EntityFrameworkCore;

namespace jQueryAjaxCrud.Data
{
    public class TransactionDbContext : DbContext
    {
        public TransactionDbContext(DbContextOptions options) : base(options)
        {
        }

        public DbSet<Transaction> Transactions { get; set; }
    }
}
