﻿using jQueryAjaxCrud.Data;
using jQueryAjaxCrud.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace jQueryAjaxCrud.Controllers
{
    public class TransactionController : Controller
    {
        private readonly TransactionDbContext _context;

        public TransactionController(TransactionDbContext context)
        {
            _context = context;
        }
        // GET: Transaction
        public async Task<IActionResult> Index()
        {
            return View(await _context.Transactions.ToListAsync());
        }

        // GET: Transaction/AddOrEdit
        // GET: Transaction/AddOrEdit/1
        public async Task<IActionResult> AddOrEdit(int id = 0)
        {
            if (id == 0)
            {
                return View(new Transaction());
            }
            var transaction = await _context.Transactions.FindAsync(id);
            if (transaction == null)
            {
                return NotFound();
            }
            return View(transaction);
        }

        // POST: Transaction/AddOrEdit
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddOrEdit(int id,[Bind("TransactionId,BeneficiaryName,BankAccountNumber,BankName,IFSCCODE,Amount,Date")]Transaction transaction)
        {
            if (ModelState.IsValid)
            {
                if (id == 0)
                {
                    transaction.Date = DateTime.Now;
                    _context.Add(transaction);
                    await _context.SaveChangesAsync();
                }
                else 
                {
                    try
                    {
                        _context.Update(transaction);
                        await _context.SaveChangesAsync();
                    }
                    catch (DbUpdateConcurrencyException)
                    {
                        if (!TransactionExists(transaction.TransactionId))
                        {
                            return NotFound();
                        }
                        else
                        {
                            throw;
                        }
                    }
                }
                return Json(new { isvalid = true, html = Helper.RenderRazorViewToString(this, "_viewAll", _context.Transactions.ToListAsync()) });
            }
            return Json(new { isvalid = false,html = Helper.RenderRazorViewToString(this, "AddOrEdit", transaction) });
        }

        // POST: Transaction/Delete/5
        [HttpPost,ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var transaction = await _context.Transactions.FindAsync(id);
            _context.Transactions.Remove(transaction);
            await _context.SaveChangesAsync();
            return Json(new { html = Helper.RenderRazorViewToString(this, "_viewAll", _context.Transactions.ToListAsync()) });
        }

        private bool TransactionExists(int id)
        {
            return _context.Transactions.Any(e => e.TransactionId == id);
        }

    }
}
