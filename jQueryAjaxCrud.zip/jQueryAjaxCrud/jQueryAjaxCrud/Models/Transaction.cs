﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace jQueryAjaxCrud.Models
{
    public class Transaction
    {
        [Key]
        public int TransactionId { get; set; }

        [Required(ErrorMessage = "This field is required")]
        [DisplayName("BeneficiaryName")]
        [Column(TypeName = "nvarchar(12)")]
        public string BeneficiaryName { get; set; }

        [MaxLength(12)]
        [Required(ErrorMessage = "This field is required")]
        [DisplayName("BankAccountNumber")]
        [Column(TypeName = "nvarchar(100)")]
        public string BankAccountNumber { get; set; }

        [Required(ErrorMessage = "This field is required")]
        [DisplayName("BankName")]
        [Column(TypeName = "nvarchar(12)")]
        public string BankName { get; set; }

        [MaxLength(11)]
        [Required(ErrorMessage = "This field is required")]
        [DisplayName("IFSCCODE")]
        [Column(TypeName = "nvarchar(12)")]
        public string IFSCCODE { get; set; }

        [Required(ErrorMessage = "This field is required")]
        public int Amount { get; set;}

        public DateTime Date {  get; set; }

    }
}
